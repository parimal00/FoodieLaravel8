<?php $__env->startSection('content'); ?>

    <div class="p-5">

        <div class="w-full">
            <form action="<?php echo e(route('categories.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <label class="text-black px-3 border-b-2 w-full">Name</label> <br>
                <input class="rounded-md w-full py-3 px-3 border-solid"type="text" name="name"
                    placeholder="category name"> <br>
               
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-800 px-3">
                        <?php echo e($message); ?> <br>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        

                <button class="bg-green-400 text-white py-2 px-3">Save</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/FoodieLaravel8/resources/views/category/create.blade.php ENDPATH**/ ?>