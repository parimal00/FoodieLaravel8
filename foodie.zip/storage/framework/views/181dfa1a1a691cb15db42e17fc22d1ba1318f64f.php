<?php $__env->startSection('content'); ?>
    <div class="p-5">
        <?php if(count($categories) > 0): ?>
            <div class="w-full">
                <form action="<?php echo e(route('items.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label class="text-black px-3 border-b-2 w-full">Name</label> <br>
                    <input class="rounded-md placeholder-gray-600 text-black w-full py-3 px-3 border-solid"type="text"
                        name="name" value="<?php echo e(old('name')); ?>" placeholder="Item name">
                    <br>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-800 px-3">
                            <?php echo e($message); ?> <br>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <label class="text-black px-3 border-b-2 w-full">Quantity</label> <br>
                    <input class="rounded-md placeholder-gray-600 text-black w-full py-3 px-3 border-solid"type="text"
                        name="quantity" value="<?php echo e(old('quantity')); ?>" placeholder="Item name">
                    <br>
                    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-800 px-3">
                            <?php echo e($message); ?> <br>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <label class="text-black px-3 border-b-2 w-full">Category</label> <br>
                    <select class="rounded-md text-black w-full py-3 px-3 border-solid bg-white" name="category_id">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="text-black" value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-800 px-3">
                            <?php echo e($message); ?> <br>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <label class="text-black px-3 border-b-2 w-full">Item image</label> <br>
                    <input type="file" name="item_image" placeholder="Upload image">
                    <?php $__errorArgs = ['item_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-800 px-3">
                            <?php echo e($message); ?> <br>
                        </span>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <label class="text-black px-3 border-b-2  w-full">Price Per Unit</label> <br>
                    <input class="rounded-md  placeholder-gray-600 text-black w-full py-3 px-3 border-solid"type="text"
                        value="<?php echo e(old('price_per_unit')); ?>" name="price_per_unit" placeholder="price per unit">
                    <br>

                    <?php $__errorArgs = ['price_per_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-800 px-3">
                            <?php echo e($message); ?> <br>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <label class="text-black px-3 border-b-2 w-full">Discount</label> <br>
                    <input class="rounded-md w-full py-3 px-3 placeholder-gray-600 text-black border-solid"type="text"
                        value="<?php echo e(old('discount')); ?>" name="discount" placeholder="Item name">
                    <br>

                    <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-800 px-3">
                            <?php echo e($message); ?> <br>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <button class="bg-green-400 text-white py-2 px-3">Save</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/FoodieLaravel8/resources/views/item/create.blade.php ENDPATH**/ ?>