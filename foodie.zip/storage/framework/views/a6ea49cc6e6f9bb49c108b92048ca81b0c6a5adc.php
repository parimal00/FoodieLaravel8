
<?php $__env->startSection('content'); ?>


    <!-- login -->
    <div class="log_page">
        <div class="img">
            <img src="<?php echo e(asset('images/log.jpg')); ?>" alt="">
        </div>
        <div class="log">
            <div class="login-contect py-5">
                <div class="container py-xl-5 py-3">
                    <div class="login-body">
                        <div class="login p-4 mx-auto">
                            <h5 class="text-center mb-4">Login Now</h5>
                            <form action="<?php echo e(route('login')); ?>" method="post">
								<?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="text" class="form-control" name="email" placeholder="email">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <span class="text-red-800"> <?php echo e($message); ?></span> 
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label class="mb-2">Password</label>
                                    <input type="password" class="form-control" name="password" placeholder="password"
                                       >
										<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="text-red-800"> <?php echo e($message); ?></span> 
									  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button type="submit" class="btn submit mb-4">Login</button>
                                <p class="forgot-w3ls text-center mb-3">
                                    <a href="#" class="text-da">Forgot your password?</a>
                                </p>
                                <p class="account-w3ls text-center text-da">
                                    Don't have an account?
                                    <a href="<?php echo e(route('user.register')); ?>">Create one now</a>
                                </p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- //login -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/FoodieLaravel8/resources/views/login.blade.php ENDPATH**/ ?>