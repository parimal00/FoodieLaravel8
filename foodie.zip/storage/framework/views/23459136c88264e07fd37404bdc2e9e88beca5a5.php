<?php $__env->startSection('content'); ?>
    @vite('resources/css/app.css')

    <div class="p-5">
        <div class="sm:hidden md:block ">
           
            <form action="<?php echo e(route('user.orders.store',[auth()->id()])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <table class="w-full">
                    <thead class="bg-gray-50 border-b-2 border-gray-200">
                        <tr>
                            <th class="text-left p-3 font-semibold tracking-wide">ID</th>
                            <th class="text-left p-3 font-semibold tracking-wide">Item Name</th>
                            <th class="text-left p-3 font-semibold tracking-wide">Item Image</th>
                            <th class="text-left p-3 font-semibold tracking-wide">Price per unit</th>
                            <th class="text-left p-3 font-semibold tracking-wide">Discount</th>
                            <th class="text-left p-3 font-semibold tracking-wide">Quantity</th>
                            <th class="text-left p-3 font-semibold tracking-wide">Total</th>
                            <th class="text-left p-3 font-semibold tracking-wide">Status</th>
                        </tr>

                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($loop->index % 2 == 0): ?>
                                <tr class="bg-white">
                                <?php else: ?>
                                <tr class="bg-gray-50">
                            <?php endif; ?>
                            <td class="text-sm w-24 font-bold hover:underline  p-3 text-blue-700"><?php echo e($order->id); ?>

                            </td>
                            <td class="text-sm p-3 w-1/3 text-gray-700"><?php echo e($order->item_name); ?></td>
                            <td class="text-sm p-3 text-gray-700"><img style="width: 100px;height:100px"
                                    src="<?php echo e($order->image_url); ?>" alt=""></td>

                            <td class="text-sm p-3 text-gray-700"><?php echo e($order->price_per_unit); ?></td>
                            <td class="text-sm p-3 text-gray-700"><?php echo e($order->discount_per_unit); ?></td>
                            <td class="text-sm p-3 text-gray-700"><?php echo e($order->amount); ?>

                            </td>
                            <td class="text-sm p-3 text-gray-700">
                                <?php echo e($order->total_price); ?>

                            </td>
                            <td class="text-sm p-3 text-gray-700">
                                <?php echo e($order->status); ?>

                            </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <button>Submit</button>
            </form>
        </div>

    </div>
    <script>
        function checkAll(){
            console.log("jck is sexy")
            carts=document.getElementsByClassName("cart_id")
            carts.setAttribute("checked")
            console.log(carts)
        }
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/FoodieLaravel8/resources/views/orders/index.blade.php ENDPATH**/ ?>