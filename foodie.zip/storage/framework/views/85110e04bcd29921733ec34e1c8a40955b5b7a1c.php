

<?php $__env->startSection('content'); ?>

@vite('resources/css/app.css')


<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <!-- menu -->
    <section class="portfolio">
        <div class="container py-xl-5 py-lg-3">
            <div class="title-section text-center mb-md-5 mb-4">
                <h3 class="w3ls-title mb-3">Our <span>Menu</span></h3>
                <p class="titile-para-text mx-auto">Inventore veritatis et quasi architecto beatae vitae dicta sunt
                    explicabo.Nemo
                    enim totam rem aperiam.</p>
            </div>
            

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($category->items) > 0): ?>
                <div class="title-section text-center mb-md-5 mb-4">
                    <h3 class="w3ls-title mb-3"><span><?php echo e($category->name); ?></span></h3>
                </div>
                <div class="grid grid-cols-1 lg:grid-cols-3 lg:gap-10">
                   
                        <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="gallery-demo"
                                onclick="showModal('<?php echo e($item->name); ?>','<?php echo e($item->price_per_unit); ?>','<?php echo e($item->discount); ?>','<?php echo e($item->getFirstMediaUrl('item_image')); ?>','<?php echo e($item->id); ?>')">
                                <a href="#gal1">
                                    <img src="<?php echo e($item->getFirstMediaUrl('item_image')); ?>" alt=" "
                                        class="img-fluid h-48" />
                                    <h4 class="p-mask"><?php echo e($item->name); ?> - <span><?php echo e($item->price_per_unit); ?></span></h4>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>

        
    </section>
    <div id="jack">

    </div>

    <!-- gallery model-->
    


    <script>
        showModal = (name, price, discount, image_url, item_id) => {
            modelWrap = document.getElementById("jack")
            modelWrap.innerHTML = `
		<div id="gal1" class="pop-overlay">
        <div class="popup">
            <form action="<?php echo e(route('user.carts.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <img style="width:100%;height:200px" class="img-fluid " src="${image_url}" alt="">
            <div class="flex flex-column items-center">
              
            <h4 class="p-mask"> ${name}- <span>${price}</span></h4>
            <h4 class="p-mask"> Discount- <span>${discount}</span></h4>
            <h4 class="p-mask"> Total- <span>${price-discount}</span></h4>

            <h4 class="p-mask"> Quantity- <span> <input type="number" placeholder="quantity" name="quantity"/></span></h4>
            </div>
           
            <input type="hidden" value="${item_id}" name="item_id">
            <div class="button-w3ls active mt-3">
           <button class="bg-yellow-400 text-black px-3 py-2 rounded"> Add to Cart</button>
                <span class="fa fa-caret-right ml-1" aria-hidden="true"></span>
            </div>
          
            <a class="close" href="#gallery">×</a>
        
        
        </form>
        </div>
    </div>`

        }
    </script>
    <script>
        $(document).ready(function() {
            <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                toastr.error('<?php echo e($message); ?>')
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <?php $__errorArgs = ['item_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                toastr.error('<?php echo e($message); ?>')
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/FoodieLaravel8/resources/views/menu.blade.php ENDPATH**/ ?>